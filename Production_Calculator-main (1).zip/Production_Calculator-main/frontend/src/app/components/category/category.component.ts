import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';
import { Category } from '../../models/interfaces';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-category',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatCardModule,
    MatSnackBarModule,
  ],
  templateUrl: './category.component.html',
  styleUrl: './category.component.css',
})
export class CategoryComponent implements OnInit {
  dataSource = new MatTableDataSource<Category>([]);
  displayedColumns: string[] = ['name', 'createdAt', 'actions'];

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.dataSource.paginator = mp;
  }
  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.dataSource.sort = ms;
  }

  loading = false;
  formVisible = false;
  editMode = false;
  saving = false;

  form: { name: string } = { name: '' };
  editId = '';

  constructor(private api: ApiService, private snackBar: MatSnackBar) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.loading = true;
    this.api.getCategories().subscribe({
      next: (data) => {
        this.dataSource.data = data;
        this.loading = false;
      },
      error: (err) => {
        this.snackBar.open(err.error?.message || 'Failed to load categories', 'Close', { duration: 3000 });
        this.loading = false;
      },
    });
  }

  applyFilter(event: Event): void {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  openCreate(): void {
    this.editMode = false;
    this.editId = '';
    this.form = { name: '' };
    this.formVisible = true;
  }

  openEdit(cat: Category): void {
    this.editMode = true;
    this.editId = cat._id;
    this.form = { name: cat.name };
    this.formVisible = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  closeForm(): void {
    this.formVisible = false;
  }

  save(): void {
    if (!this.form.name.trim()) {
      this.snackBar.open('Category name is required', 'Close', { duration: 3000 });
      return;
    }
    this.saving = true;

    const req = this.editMode
      ? this.api.updateCategory(this.editId, this.form)
      : this.api.createCategory(this.form);

    req.subscribe({
      next: () => {
        this.saving = false;
        this.snackBar.open(this.editMode ? 'Category updated!' : 'Category created!', 'Close', { duration: 3000 });
        this.formVisible = false;
        this.load();
      },
      error: (err) => {
        this.snackBar.open(err.error?.message || 'Failed to save', 'Close', { duration: 3000 });
        this.saving = false;
      },
    });
  }

  delete(id: string, name: string): void {
    if (!confirm(`Delete category "${name}"?`)) return;
    this.api.deleteCategory(id).subscribe({
      next: () => {
        this.snackBar.open('Category deleted', 'Close', { duration: 3000 });
        this.load();
      },
      error: (err) => {
        this.snackBar.open(err.error?.message || 'Failed to delete', 'Close', { duration: 3000 });
      },
    });
  }
}
